create
    definer = root@localhost procedure insert_user()
BEGIN
	DECLARE num int;
	SET num = 1;
	WHILE num <= 10
	DO
	INSERT INTO sys_user(account, password, name, avatar, age) VALUES(CONCAT(num,num,num),CONCAT(num,num,num),CONCAT(num,'号'),CONCAT(num,'.jpg'),18);
	SET num = num + 1;
	END WHILE;
END;

